import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';
import { ProviderService } from '../provider.service';

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent implements OnInit {
  invoiceForm: FormGroup;
  invoiceItems: FormArray;
  lstCustomer = [];
  lstItem = [];
  isAutoGenerate: boolean = false;
  iAmount: number;
  typeOfDiscount: string = "dollar";
  localStorageArray: any = [];
  tempDiscount: number;
  shippingCharge: number;
  subTotal: number;
  finalTotal: number;
  itemPrice = [];
  // ip: number;
  amount = [];
  min: any;
  iNumber: number;
  addedItems: any = []

  constructor(private fb: FormBuilder, private provider: ProviderService) {

  }

  ngOnInit() {

    if (localStorage.getItem('itemList')) {

      this.lstItem = JSON.parse(localStorage.getItem('itemList'))
    } else {
      this.lstItem = this.provider.getItemList();
    }
    if (localStorage.getItem('customerList')) {

      this.lstCustomer = JSON.parse(localStorage.getItem('customerList'))
    } else {
      this.lstCustomer = this.provider.getCustomerList();
    }

    this.invoiceForm = this.fb.group({
      custName: [this.lstCustomer[0].name, Validators.required],
      invoiceNo: ['', Validators.compose([Validators.required, Validators.pattern('[0-9]\\d{5}')])],
      orderNo: ['', Validators.required],
      invoiceDate: ['', Validators.required],
      dueDate: ['', Validators.required],
      invoiceItems: this.fb.array([])
    })

  }

    addItem(): void {
     const creds = this.invoiceForm.controls.invoiceItems as FormArray;
    creds.push(this.fb.group({
      itemName: [this.lstItem[0].id, Validators.required],
      itemQuantity: [1, Validators.required],
      itemRate: [this.lstItem[0].amount, Validators.required],
      itemAmount: [this.lstItem[0].amount]
    }))
     
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    // let l = form.controls[i].get('itemQuantity').value
    this.finalTotal=0;
for (let i = 0; i < form.length; i++) {
   this.finalTotal+= form.controls[i].get('itemAmount').value;
}
    // form.controls[i].get('itemAmount').setValue(l * form.controls[i].get('itemRate').value)


  }

  generateInvoice() {
    if (this.invoiceForm.valid) {

      let iDate = this.invoiceForm.value.invoiceDate;
      let dDate = this.invoiceForm.value.dueDate;
      if (dDate < iDate) {
        alert("Due date can not be less than issued date")
      } else {

        if (localStorage.getItem('createdInvoice')) {
          // alert("YES")  
          this.localStorageArray = JSON.parse(localStorage.getItem('createdInvoice'));

          // const data = this.invoiceForm.controls['invoiceItems'].value;
          // const rate = this.invoiceForm.controls['invoiceItems'].value[i].itemRate;

          const data = this.invoiceForm.value;

          if (this.isAutoGenerate) {
            data.invoiceNo = this.min;
          }
          else {
            data.invoiceNo = this.iNumber;
          }
          // data.invoiceNo = this.min;

          // if (this.isAutoGenerate) {
          //   // console.log("number",this.iNumber);

          //   // this.iNumber = Number(this.iNumber)+1;
          //   // console.log('this.iNumber:', this.iNumber)
          //   // data.invoiceNo =  '00000' + this.iNumber;
          //   this.min+=1;
          //   this.min = '00000'+this.min;
          //   console.log("MIN",this.min);

          //    data.invoiceNo = this.min;
          // } else {
          //   console.log("INUMBER",this.iNumber);

          //   data.invoiceNo = this.iNumber;
          // }

          data.amount = this.finalTotal
          this.localStorageArray.push(data);
          localStorage.setItem('createdInvoice', JSON.stringify(this.localStorageArray))

        } else {
          // alert("NO")
          this.localStorageArray = [];
          const data = this.invoiceForm.value;
          if (this.isAutoGenerate) {
            data.invoiceNo = this.min;
          }
          // data.invoiceNo = this.min;
          // if (this.isAutoGenerate) {
          //   console.log('this.iNumber:', this.iNumber)

          //   data.invoiceNo = '000001'
          //   // data.invoiceNo = 123;
          //   console.log("DATA",data);

          //   // console.log("data2",data.invoiceNo);

          // } else {

          //   data.invoiceNo = this.iNumber;
          // }

          data.amount = this.finalTotal


          this.localStorageArray.push(data);

          console.log(this.localStorageArray);

          localStorage.setItem('createdInvoice', JSON.stringify(this.localStorageArray));
        }


        this.invoiceForm.reset();

      }
    } else {
      alert("Invalid form")
    }
  }

  autoGenerate(val) {

    this.isAutoGenerate = !this.isAutoGenerate;
    if (this.isAutoGenerate) {

      this.localStorageArray = JSON.parse(localStorage.getItem('createdInvoice'));
      if (this.localStorageArray) {
        alert("YES")
        try {
          this.min = Number(this.localStorageArray[0].invoiceNo);
          for (let i = 0; i < this.localStorageArray.length; i++) {
            if (this.localStorageArray[i].invoiceNo > this.min) {
              this.min = this.localStorageArray[i].invoiceNo;
            }
          }
          // this.min+=1;
          this.min = Number(this.min) + 1;


          this.min = '00000' + this.min;
          console.log("min", this.min);
        } catch (error) {
        }

      } else {
        alert("NO")
        this.min = '000001';
        console.log(this.min);
      }

      // if (!this.min) {


      // } 
      // else {
      //   console.log("loop");

      //   // this.min = Number(this.min) + 1;
      //   console.log(this.min);
      // }
      this.invoiceForm.patchValue({
        invoiceNo: this.min
      })
      this.invoiceForm.controls['invoiceNo'].disable();

    } else {
      console.log("FALSE");
      this.invoiceForm.patchValue({
        invoiceNo: ""
      })
      this.invoiceForm.controls['invoiceNo'].enable();
    }
  }
  validateDate(){
    let iDate = this.invoiceForm.value.invoiceDate;
    let dDate = this.invoiceForm.value.dueDate;
    if (dDate < iDate) {
      alert("Due date can not be less than issued date")
    }

  }
  calAmount(i, val) {
 
    // const quantity = this.invoiceForm.controls['invoiceItems'].value[i].itemQuantity;
    // const rate = this.itemPrice[i];
    //  this.amount.push(rate * quantity);
    // this.subTotal = 0;
    // for (let i = 0; i < this.amount.length; i++) {
    //   this.subTotal += this.amount[i];
    // }
    // this.finalTotal = this.subTotal;
    // this.iAmount = rate * quantity;

    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    let l = form.controls[i].get('itemQuantity').value
    form.controls[i].get('itemAmount').setValue(l * form.controls[i].get('itemRate').value)
    console.log("L", l);

    // form.controls[index].get('itemAmount').setValue(1 * it.amount)
    this.subTotal = 0;
    for (let i = 0; i < form.length; i++) {
      this.subTotal += form.controls[i].get('itemAmount').value
    }this.finalTotal = this.subTotal;

  }   
  callDiscount(val) {
    
    this.typeOfDiscount = val;
    var form = <FormArray>this.invoiceForm.get('invoiceItems');

    if (this.typeOfDiscount == "dollar") {
      console.log("DOLLAR");
      
      this.subTotal=0
      for(let i=0;i<form.length;i++){
        this.subTotal+=form.controls[i].get('itemAmount').value
      }
       
      this.finalTotal = this.subTotal-val;
      console.log("f",this.finalTotal);
      
      // console.log('this.discount:', this.discount)
        

    }else{
      this.subTotal=0;
      for(let i=0;i<form.length;i++){
        this.subTotal+=form.controls[i].get('itemAmount').value;
      }
      let x = (this.subTotal * val) / 100;
      this.finalTotal = this.subTotal-x
      console.log("x",x);
      

    }

    
  }
  discount : number=0;
  calculateDiscount(val) {
    console.log("CALVAL",val);
    
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    this.finalTotal =0;
    if (this.typeOfDiscount == "dollar") {
      this.subTotal=0
      for(let i=0;i<form.length;i++){
        this.subTotal+=form.controls[i].get('itemAmount').value
      }
      console.log("subtotal",this.subTotal);
      
      this.finalTotal = this.subTotal-val;
      console.log('this.discount:', this.discount)
        

    }else{
      this.subTotal=0;
      for(let i=0;i<form.length;i++){
        this.subTotal+=form.controls[i].get('itemAmount').value;
      }
      let x = (this.subTotal * val) / 100;
      this.finalTotal = this.subTotal-x
      console.log("x",x);
      

    }

    console.log("VAL",val);
    
    this.tempDiscount = val;
    // this.finalTotal -= this.tempDiscount;

    console.log('this.tempDiscount:', this.tempDiscount)
  }
  calShippingCharge(val) {
    this.shippingCharge = val;

    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    this.finalTotal+= Number(val);


    
  }
  itemChanged(item, index) {
    //index is formArray index
    let x;
    const it = this.lstItem.find(x => x.id == item)
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    form.controls[index].get('itemRate').setValue(it.amount);
    form.controls[index].get('itemAmount').setValue(1 * it.amount)
    this.subTotal = 0
    for (let i = 0; i < form.length; i++) {
      this.subTotal += form.controls[i].get('itemAmount').value;
    }
    this.finalTotal=this.subTotal
 

  
  }
  storeInvoice(val) {
    this.iNumber = val;
  }
}

