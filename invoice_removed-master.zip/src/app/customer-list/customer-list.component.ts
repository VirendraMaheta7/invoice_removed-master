import { Component, OnInit, ViewChild } from '@angular/core';
import { ProviderService } from '../provider.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  addCustomerForm : FormGroup;
  lstCustomer = [];
  isEdit : boolean = false;
  custId : number;
  @ViewChild('customerModal') customerModal: ModalDirective;

  constructor(private provider : ProviderService, private fb : FormBuilder) {
    
  }
  
  ngOnInit() {
    if(!localStorage.getItem('customerList')){

      this.lstCustomer = this.provider.getCustomerList();
    }else{
      this.lstCustomer = JSON.parse(localStorage.getItem('customerList'))
    }
    this.initCustomerForm();
  }
  initCustomerForm(){
    this.addCustomerForm = this.fb.group({
      cName : ['', Validators.required],
      cNumber : ['', Validators.required],
      cAddress : ['', Validators.required]
    })
  }

  openCustomerModal(){
    this.customerModal.show();
  }
  submitCustomerForm(){
    console.log("SUBMIT");
    
    if(this.addCustomerForm.valid){

      if(this.isEdit == true){
        // this.lstCustomer.splice(this.custId,1,this.addCustomerForm.value);
        for(let i=0;i<this.lstCustomer.length;i++){
          if(i== this.custId){
            this.lstCustomer[i].name = this.addCustomerForm.value.cName;
            this.lstCustomer[i].mobile = this.addCustomerForm.value.cNumber;
            this.lstCustomer[i].city = this.addCustomerForm.value.cAddress
            
          }
          this.isEdit = false;
        }

        console.log(this.lstCustomer);
        
      }
      else{
      const data = {
        id : this.lstCustomer.length+1,
        name : this.addCustomerForm.value.cName,
        mobile : this.addCustomerForm.value.cNumber,
        city : this.addCustomerForm.value.cAddress
      }
      if(localStorage.getItem('customerList')){
        this.lstCustomer = JSON.parse(localStorage.getItem('customerList'));
        this.lstCustomer.splice(this.lstCustomer.length+1,0,data);
        localStorage.setItem('customerList',JSON.stringify(this.lstCustomer));
      }else{
        this.lstCustomer.splice(this.lstCustomer.length+1,0,data);
        localStorage.setItem('customerList',JSON.stringify(this.lstCustomer));
      }
      console.log(this.lstCustomer);
      
       }
      this.customerModal.hide();
    }
  }

  
  editCustomer(cust,id){
    this.isEdit = true;
    this.custId = id;

    this.customerModal.show();
    this.addCustomerForm.patchValue({
      cName : cust.name,
      cNumber : cust.mobile,
      cAddress : cust.city
    })
    
  }
  deleteCustomer(i){
    this.lstCustomer.splice(i,1);
  }
  closeDeptModal(){
    this.customerModal.hide();
  }
}
