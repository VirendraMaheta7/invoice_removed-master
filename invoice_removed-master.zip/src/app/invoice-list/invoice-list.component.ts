import { Component, OnInit } from '@angular/core';
import { ProviderService } from '../provider.service';

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent implements OnInit {

  constructor(private provider : ProviderService) { }
lstInvoice = [];
  ngOnInit() {

    // this.lstInvoice = this.provider.getCreatedInvoices();
    try {
      
      this.lstInvoice = JSON.parse(localStorage.getItem('createdInvoice'));
    } catch (error) {
      
    }
    if(this.lstInvoice){
      for(let i=0; i<this.lstInvoice.length;i++){
        if(this.lstInvoice[i].invoiceNo == '00000'){
          this.lstInvoice[i].invoiceNo = '000001'
        }else{
          console.log("IN",this.lstInvoice[i].invoiceNo);
          
        }
      }
    }
    else{
      alert("No records found!")
    }
      
  }

}
