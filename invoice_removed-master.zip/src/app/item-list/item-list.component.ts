import { Component, OnInit, ViewChild } from '@angular/core';
import { ProviderService } from '../provider.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {
lstItem = [];
addItemForm : FormGroup;
isEditItem : boolean = false;
itemId : number;
@ViewChild('itemModal') itemModal: ModalDirective;

  constructor(private provider : ProviderService, private fb : FormBuilder) { 

    
  }

  ngOnInit() {
    if(!localStorage.getItem('itemList')){

      this.lstItem = this.provider.getItemList();
    }else{
      this.lstItem = JSON.parse(localStorage.getItem('itemList'))
    }
    this.initItemForm();
  }
  addItem(){
 this.itemModal.show();
  }
  initItemForm(){
    this.addItemForm = this.fb.group({
      itName : ['',Validators.required],
      itPrice : ['', Validators.required]
    })
  }
  submitItem(){

    if(this.addItemForm.valid){

      if(this.isEditItem == true){
        for(let i=0;i<this.lstItem.length;i++){
          if(i==this.itemId){
            this.lstItem[i].name = this.addItemForm.value.itName;
            this.lstItem[i].amount = this.addItemForm.value.itPrice;
          }
          
        }
        this.isEditItem = false;
      }
      else{
        const data = {
          id : this.lstItem.length+1,
          name : this.addItemForm.value.itName,
          amount : this.addItemForm.value.itPrice,
        }
        //Add into localstorage
        // this.lstItem.splice(this.lstItem.length+1,0,data);

        if(localStorage.getItem('itemList')){
          this.lstItem = JSON.parse(localStorage.getItem('itemList'));
          this.lstItem.splice(this.lstItem.length+1,0,data);
          localStorage.setItem("itemList",JSON.stringify(this.lstItem));
        }else{
            alert("NOT AVAILABLE")
            this.lstItem.splice(this.lstItem.length+1,0,data);
            localStorage.setItem("itemList",JSON.stringify(this.lstItem));
        }

        console.log("X",this.provider.getItemList());
      }
      this.addItemForm.reset();
      this.itemModal.hide();
    }
  }
  closeDeptModal(){
    this.itemModal.hide();
  }

  editItem(item,i){
    this.isEditItem = true;
    this.itemId = i;
    this.itemModal.show();
    this.addItemForm.patchValue({
      itName : item.name,
      itPrice : item.amount
      
    })
  }
  deleteItem(i){
    this.lstItem.splice(i,1);
  }
}
